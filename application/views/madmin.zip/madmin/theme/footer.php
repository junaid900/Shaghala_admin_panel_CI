<div class="footer">
    <div>
        <strong>Copyright</strong> Example Company &copy; 2021
    </div>
</div>
